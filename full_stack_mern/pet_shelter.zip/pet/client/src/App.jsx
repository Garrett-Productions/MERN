import './App.css'
import { useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import DisplayAll from './components/DisplayAll';
import ViewOne from './components/ViewOne';
import EditOne from './components/EditOne';
import CreateOne from './components/CreateOne';

function App() {
//be intentional on where you set state, and clean up before submitting, any unused lifted state
  const [petList, setPetList] = useState([]);

  const removePet = petId => {
    setPetList(petList.filter(pet => pet._id !== petId));
  }
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element= {<DisplayAll petList = {petList} setPetList={setPetList} /> }/>
          <Route path='/pets/new' element={<CreateOne petList = {petList} setPetList={setPetList}/> }/>
          <Route path='/pets/:id' element={<ViewOne removePet={removePet}/>}/>
          <Route path='/pet/:id/edit' element={<EditOne petList = {petList} setPetList={setPetList}/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
