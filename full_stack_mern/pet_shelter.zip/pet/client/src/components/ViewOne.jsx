import React, {useState, useEffect} from 'react';
import axios from 'axios';
import {useParams, Link, useNavigate} from 'react-router-dom';

const ViewOne = ({removePet}) => {
//use params to pull in ID of specific object
//create likes by creating a num in state, and then a state variable for the like button itself to hide once clicked
    const {id} = useParams();
    const [pet, setPet] = useState([]);
    const [likes, setLikes] = useState(0); // to capture a like in state
    const [show, setShow] = useState(true); // to conditionally render the like button
    const navigate = useNavigate();
    
    useEffect(() => {
        axios.get(`http://localhost:8000/api/pet/${id}`)
        .then(res => {
            console.log(res.data)
            setPet(res.data)
        })
        .catch(err => console.log(err));
    }, [])

    const deletePet = (petId) => {
        axios.delete(`http://localhost:8000/api/pet/${petId}`)
            .then(res => {
                removePet(petId)
                navigate('/')
            })
            .catch(err => console.log(err))
    }

    const handleLikeClick = () => {
        setLikes(likes + 1);
        setShow(false)
    }

    return (
        <div style={{width:"900px", margin:"0px auto"}}>
            <div style={{display:"flex", justifyContent:"space-between"}}> 
                <h1 className='text-5xl'> Pet Shelter</h1>
                <Link to={'/'} style={{color:"blue"}} className='underline'>Back To home</Link>
            </div><br />
            <div style={{display:"flex", justifyContent:"space-between"}}> 
                <h2 className='text-left mx-5 text-3xl'>Details about: {pet.name}</h2><br />
                <button onClick ={(e) => {deletePet(pet._id)}} className='bg-red-400' style={{border:"1px solid black", padding:"5px", boxShadow:"3px 3px black", textDecoration:"underline"}}>Adopt {pet.name}</button>
            </div><br />
            <div style={{border:"1px solid black", width:"850px"}}>
                <h3 className='text-left text-2xl'> Pet Type: <span style={{fontStyle:"italic", color:"blue"}}>{pet.type}</span></h3>
                <h3 className='text-left text-2xl'> Description: <span style={{fontStyle:"italic", color:"blue"}}>{pet.description}</span> </h3><hr/>
                <div >
                    <p className='text-left text-2xl my-2'>Skills Include: 
                        <div className='text-center'>
                            {pet.skillOne ? <p className='underline'>{pet.skillOne} </p> : "" }
                            {pet.skillTwo ? <p className='underline'>{pet.skillTwo}</p> : "" }
                            {pet.skillThree ? <p className='underline'>{pet.skillThree}</p> : "" }
                        </div>
                    </p><hr/>
                </div>
                <div className='p-2 flex justify-around m-1'>
                    <h3 className='text-left text-2xl bg-blue-400' style={{borderRadius:"50%", padding:"6px"}}>Likes: {likes}</h3>
                    {  show ? 
                        <div style={{display:"flex", justifyContent:"left", alignItems:"baseline" }}><br/>
                            <button 
                                style={{border:"1px solid black", borderRadius:"50%", background:"lightBlue", padding:"5px", boxShadow:"1px 1px black", margin:"2px"}} 
                                onClick={handleLikeClick}>Like Me
                            </button>
                            <p>Show me some love?</p>
                        </div>
                    : ''}
                </div>
            </div>
        </div>
    )
}

export default ViewOne;